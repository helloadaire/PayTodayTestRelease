(($) => {
    'use strict';

    let pt_ui_init = false;

    if (typeof PayToday === 'undefined') {
        console.error('PayToday SDK not loaded');
        return;
    }

    if (paytoday_params && paytoday_params.is_enabled == "no") {
        console.info("This paymentflow will not use PayToday because it's disabled!");
        return;
    }

    const paytoday = new PayToday({
        shopKey: paytoday_params.shop_key,
        shopHandle: paytoday_params.shop_handle,
        privateKey: paytoday_params.private_key,
        environment: paytoday_params.environment
    });

    // Store original button state
    let originalButtonState = {
        src: 'https://nedbankstorage.blob.core.windows.net/nedbankclouddatadisk/staticazure/web/sdk/img/paytoday-web-payment-button.png',
        width: '100%',
        maxWidth: '250px',
        cursor: 'pointer'
    };

    async function handlePayTodayCheckout() {
        const paytodayButton = document.getElementById('paytoday-payment-button');
        const paytodayButtonContainer = document.getElementById('paytoday-payment-button-container');
        if (!paytodayButton || !paytodayButtonContainer) {
            console.error('PayToday button elements not found');
            return;
        }

        try {
            paytodayButtonContainer.style.background = "transparent";
        } catch (error) {
            console.warn(error);
        }

        // Set loading state
        setButtonLoadingState(paytodayButtonContainer, true);

        try {
            await paytoday.initialize();
            
            const [orderResponse, cartResponse] = await Promise.all([
                fetch('/wp-json/wc/store/v1/checkout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Nonce': paytoday_params.store_api_nonce
                    },
                    body: JSON.stringify({
                        billing_address: '',
                        shipping_address: '',
                        payment_method: 'paytoday',
                        customer_note: 'Pay with PayToday',
                        billing_address_same_as_shipping: true,
                        terms: true
                    })
                }),
                fetch('/wp-json/wc/store/v1/cart', {
                    headers: {
                        'Content-Type': 'application/json',
                        'Nonce': paytoday_params.store_api_nonce
                    }
                })
            ]);

            const [result, cart] = await Promise.all([
                orderResponse.json(),
                cartResponse.json()
            ]);

            const cartTotal = `${cart.totals?.total_price || '0'}`;

            if (!orderResponse.ok || !result.order_id || !cartTotal) {
                throw new Error(result.message || 'Order creation failed');
            }

            const customer = result.billing_address || {};

            // Validate required fields
            const requiredFields = {
                'First name': customer.first_name,
                'Last name': customer.last_name,
                'Email address': customer.email,
                'Phone number': customer.phone
            };

            for (const [fieldLabel, value] of Object.entries(requiredFields)) {
                if (!value || value.trim() === '') {
                    throw new Error(`Missing required field: ${fieldLabel}`);
                }
            }

            const orderData = {
                amount: Math.round(parseFloat(`${cartTotal}`.replaceAll('.','').replaceAll(',','')) / 100),
                invoice_number: result.order_id,
                user_first_name: customer.first_name,
                user_last_name: customer.last_name,
                user_email: customer.email,
                user_phone_number: customer.phone,
                return_url: `${window.location.origin}/wc-api/paytoday_return/?order_id=${result.order_id}`
            };

            const paymentIntent = await paytoday.createPaymentIntent(orderData);

            if (!paymentIntent.data.payment_url) {
                throw new Error('No payment URL received');
            }

            // Success - redirect to payment URL
            window.location.href = paymentIntent.data.payment_url;

        } catch (error) {
            console.error('PayToday Checkout Error:', error);
            
            // Reset button state on error
            setButtonLoadingState(paytodayButtonContainer, false);
            
            const error_message = error.message || paytoday_params.i18n.error;
            if (`${error_message}`.includes('Unexpected token')) {
                displayFriendlyError("Your version of WooCommerce is outdated, and does not support Blocks Payments Integrations! Please contact PayToday support!");
            } else {
                displayFriendlyError(error_message);
            }
        }
    }

    function setButtonLoadingState(container, isLoading) {
        if (!container) return;
        
        const button = container.querySelector('#paytoday-payment-button');
        if (!button) return;
        
        // Create loading element if it doesn't exist
        let loadingElement = container.querySelector('#paytoday-loading-element');
        
        if (isLoading) {
            // Hide button and disable it
            button.style.display = 'none';
            button.disabled = true;
            
            // Create and show loading element
            if (!loadingElement) {
                loadingElement = document.createElement('img');
                loadingElement.id = 'paytoday-loading-element';
                loadingElement.src = 'https://nedbankstorage.blob.core.windows.net/nedbankclouddatadisk/staticazure/img/paytoday_animation.gif';
                loadingElement.style.width = '40px';
                loadingElement.style.height = '40px';
                loadingElement.style.display = 'block';
                loadingElement.style.margin = '0 auto';
                container.appendChild(loadingElement);
            } else {
                loadingElement.style.display = 'block';
            }
        } else {
            // Show button and enable it
            button.style.display = 'block';
            button.disabled = false;
            
            // Hide loading element if it exists
            if (loadingElement) {
                loadingElement.style.display = 'none';
            }
        }
    }

    function displayFriendlyError(message) {
        const noticeContainer = document.querySelector('.wc-block-components-notices') || 
                               document.querySelector('.woocommerce-notices-wrapper') ||
                               document.querySelector('.woocommerce-error, .woocommerce-message');
        
        if (noticeContainer) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'woocommerce-error';
            errorDiv.innerHTML = message;
            
            // Clear existing notices
            noticeContainer.innerHTML = '';
            noticeContainer.appendChild(errorDiv);
            
            window.scrollTo({ top: noticeContainer.offsetTop - 100, behavior: 'smooth' });
        } else {
            alert(message); // fallback
        }
    }

    // Initialize button with event delegation
    document.addEventListener('DOMContentLoaded', function() {
        document.body.addEventListener('click', function(e) {
            if (e.target && e.target.id === 'paytoday-payment-button') {
                e.preventDefault();
                handlePayTodayCheckout();
            }
        });
    });

    // Button injection logic
    const interval = setInterval(() => {
        const container = document.querySelector('.wc-block-checkout__no-payment-methods-notice');
        if (container && !document.querySelector('#paytoday-payment-button')) {
            container.innerHTML = `
                <div id="paytoday-payment-button-container" style="margin-top: 20px; text-align: center;">
                    <img style="width:100%;max-width: 250px;cursor: pointer;" id="paytoday-payment-button" class="button alt" src="https://nedbankstorage.blob.core.windows.net/nedbankclouddatadisk/staticazure/web/sdk/img/paytoday-web-payment-button.png">
                </div>
            `;
            container.style.background = 'white';
            container.style.border = 'none';
            clearInterval(interval);
        }
    }, 300);

    // Alternative button injection for non-block checkout
    (function() {
        const interval = setInterval(() => {
            let placeOrderBtn = document.querySelector('.wc-block-components-checkout-place-order-button') ||
                                document.querySelector('form.woocommerce-checkout button[type="submit"]');
            if (placeOrderBtn) {
                clearInterval(interval);

                try {
                    const paymentFieldset = document.querySelector('fieldset#wc-block-checkout__payment-method, fieldset#payment-method');
                    if (paymentFieldset) {
                        paymentFieldset.style.display = 'none';
                    }
                } catch (error) {
                    console.log(error);
                }

                placeOrderBtn.style.display = 'none';

                const container = document.createElement('div');
                container.id = 'paytoday-payment-button-container';
                container.style.marginTop = '20px';
                container.style.textAlign = 'center';

                const paytodayButton = document.createElement('img');
                paytodayButton.src = originalButtonState.src;
                paytodayButton.id = 'paytoday-payment-button';
                paytodayButton.className = 'button alt';
                paytodayButton.style.cssText = 'width:100%;max-width:250px;cursor:pointer;';

                container.appendChild(paytodayButton);
                placeOrderBtn.parentNode.insertBefore(container, placeOrderBtn.nextSibling);
            }
        }, 100);
    })();

})(jQuery);