const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { decodeEntities } = window.wp.htmlEntities;
const { getSetting } = window.wc.wcSettings;

const settings = getSetting('paytoday_data', {});
const defaultLabel = decodeEntities(settings.title) || __('PayToday', 'paytoday-woocommerce');
const label = decodeEntities(settings.title) || defaultLabel;

const Content = () => {
    return decodeEntities(settings.description || '');
};

const Label = (props) => {
    const { PaymentMethodLabel } = props.components;
    return <PaymentMethodLabel text={label} />;
};

const PayTodayPaymentMethod = {
    name: 'paytoday',
    label: <Label />,
    content: <Content />,
    edit: <Content />,
    canMakePayment: () => true,
    ariaLabel: label,
    supports: {
        features: settings.supports || [],
    },
    paymentMethod: () => true,
};

registerPaymentMethod(PayTodayPaymentMethod);