const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { decodeEntities } = window.wp.htmlEntities;
const { getSetting } = window.wc.wcSettings;
const { __ } = window.wp.i18n;

const settings = getSetting('paytoday_data', {});
const defaultLabel = decodeEntities(settings.title) || __('PayToday', 'paytoday-woocommerce');
const label = decodeEntities(settings.title) || defaultLabel;

const Content = () => {
    return <p>{decodeEntities(settings.description || '')}</p>;
};

const Label = (props) => {
    const { PaymentMethodLabel } = props.components;
    return <PaymentMethodLabel text={label} />;
};

const PayTodayPaymentMethod = {
    name: 'paytoday',
    label: <Label />,
    content: <Content />,
    edit: <Content />,
    canMakePayment: () => true,
    ariaLabel: label,
    supports: {
        features: settings.supports || [],
    },
    placeOrder: async () => {
        try {
            const checkoutData = window.wc?.blocksCheckout?.getCheckoutData?.();

            if (!checkoutData) {
                throw new Error('Could not retrieve checkout form data');
            }

            const response = await fetch('/wp-json/wc/store/v1/checkout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Nonce': paytoday_params.store_api_nonce
                },
                body: JSON.stringify({
                    billing_address: checkoutData.billingAddress,
                    shipping_address: checkoutData.shippingAddress,
                    payment_method: 'paytoday',
                    customer_note: checkoutData.customerNote || '',
                    billing_address_same_as_shipping: checkoutData.billingAsShipping,
                    terms: checkoutData.terms
                })
            });

            const result = await response.json();

            if (!response.ok || !result.order_id || !result.order_total) {
                throw new Error(result.message || 'Order creation failed');
            }

            const customer = result.billing_address || {};
            const orderData = {
                amount: Math.round(parseFloat(result.order_total) * 100),
                invoice_number: result.order_id,
                user_first_name: customer.first_name || '',
                user_last_name: customer.last_name || '',
                user_email: customer.email || '',
                user_phone_number: customer.phone || '',
                return_url: window.location.href
            };

            const paymentIntent = await PayToday.createPaymentIntent(orderData);

            if (!paymentIntent.payment_url) {
                throw new Error('No payment URL received');
            }

            // Step 4: Redirect to PayToday payment page
            window.location.href = paymentIntent.payment_url;

            return true;
        } catch (error) {
            console.error('PayToday Error:', error);
            return {
                type: 'error',
                message: __('PayToday payment failed. Please try again.', 'paytoday-woocommerce')
            };
        }
    }
};

registerPaymentMethod(PayTodayPaymentMethod);
