<?php

class Puc_v4p13_Plugin_Ui {
    private $updateChecker;
    private $manualCheckErrorTransient = '';

    public function __construct($updateChecker) {
        $this->updateChecker = $updateChecker;
        $this->manualCheckErrorTransient = 'puc_manual_check_' . $updateChecker->slug;

        add_action('admin_init', array($this, 'onAdminInit'));
        add_action('admin_notices', array($this, 'onAdminNotices'));
        add_action('network_admin_notices', array($this, 'onAdminNotices'));
        add_action('plugin_action_links_' . $updateChecker->pluginFile, array($this, 'addCheckForUpdatesLink'));
        add_action('after_plugin_row_' . $updateChecker->pluginFile, array($this, 'addCheckForUpdatesLink'));
    }

    public function onAdminInit() {
        if (isset($_GET['puc_check_for_updates']) && $_GET['puc_check_for_updates'] == '1') {
            $update = $this->updateChecker->checkForUpdates();
            $status = ($update === null) ? 'no_update' : 'update_available';
            wp_redirect(add_query_arg(
                array(
                    'puc_update_check_result' => $status,
                    'puc_slug' => $this->updateChecker->slug,
                ),
                remove_query_arg('puc_check_for_updates')
            ));
            exit;
        }
    }

    public function onAdminNotices() {
        if (isset($_GET['puc_update_check_result']) && $_GET['puc_slug'] == $this->updateChecker->slug) {
            $message = null;
            $isError = false;

            switch ($_GET['puc_update_check_result']) {
                case 'no_update':
                    $message = __('This plugin is up to date.', 'paytoday-woocommerce');
                    break;
                case 'update_available':
                    $message = __('A new version of this plugin is available.', 'paytoday-woocommerce');
                    break;
                case 'error':
                    $message = __('An error occurred while checking for updates.', 'paytoday-woocommerce');
                    $isError = true;
                    break;
            }

            if ($message) {
                printf(
                    '<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
                    $isError ? 'error' : 'success',
                    esc_html($message)
                );
            }
        }
    }

    public function addCheckForUpdatesLink($links) {
        $link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(add_query_arg('puc_check_for_updates', '1')),
            __('Check for Updates', 'paytoday-woocommerce')
        );
        if (is_array($links)) {
            $links[] = $link;
        } else {
            $links = array($links, $link);
        }
        return $links;
    }
}
