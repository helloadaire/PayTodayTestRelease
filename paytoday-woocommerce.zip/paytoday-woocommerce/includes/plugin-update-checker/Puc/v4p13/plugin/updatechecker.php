<?php

class Puc_v4p13_Plugin_UpdateChecker extends Puc_v4p13_UpdateChecker {
    protected $updateTransient = 'update_plugins';
    protected $transientType = 'plugin';
    protected $extraUi = null;

    public function __construct($metadataUrl, $pluginFile, $slug = '', $checkPeriod = 12, $optionName = '', $muPluginFile = '') {
        parent::__construct($metadataUrl, $pluginFile, $slug, $checkPeriod, $optionName, $muPluginFile);

        // Set up the extra UI
        if (is_admin()) {
            $this->extraUi = new Puc_v4p13_Plugin_Ui($this);
        }
    }

    protected function createDebugBarExtension() {
        if (class_exists('Debug_Bar')) {
            return new Puc_v4p13_DebugBar_PluginExtension($this);
        }
        return null;
    }

    protected function getUpdateListTransient() {
        return get_site_transient($this->updateTransient);
    }

    protected function setUpdateListTransient($value) {
        set_site_transient($this->updateTransient, $value, 3 * HOUR_IN_SECONDS);
    }

    protected function getCronHookName() {
        return 'check-plugin-updates-' . $this->slug;
    }

    public function getUpdate($force = false) {
        $update = parent::getUpdate($force);
        if ($update !== null) {
            $update->id = $this->pluginFile;
        }
        return $update;
    }

    public function requestUpdate($queryArgs = array()) {
        $queryArgs['installed_version'] = $this->getInstalledVersion();
        $queryArgs['plugin'] = $this->pluginFile;

        $url = add_query_arg($queryArgs, $this->metadataUrl);
        $result = wp_remote_get($url, array(
            'timeout' => 15,
        ));

        if (is_wp_error($result)) {
            return $result;
        }

        $responseCode = wp_remote_retrieve_response_code($result);
        if ($responseCode !== 200) {
            return new WP_Error(
                'puc-http-error',
                sprintf('HTTP error %d while checking for updates.', $responseCode)
            );
        }

        $update = $this->parseMetadataResponse(wp_remote_retrieve_body($result));
        if (is_wp_error($update)) {
            return $update;
        }

        return $update;
    }

    protected function parseMetadataResponse($response) {
        $plugin = get_plugin_data($this->pluginFile);
        $pluginInfo = new Puc_v4p13_Plugin_Info();
        $pluginInfo->filename = $this->pluginFile;
        $pluginInfo->slug = $this->slug;

        $pluginInfo->version = $plugin['Version'];
        $pluginInfo->title = $plugin['Name'];
        $pluginInfo->homepage = $plugin['PluginURI'];
        $pluginInfo->sections = array(
            'description' => $plugin['Description'],
        );

        return $pluginInfo;
    }

    public function getInstalledVersion() {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . '/wp-admin/includes/plugin.php');
        }
        $pluginHeader = get_plugin_data($this->pluginFile, false, false);
        return array_key_exists('Version', $pluginHeader) ? $pluginHeader['Version'] : '';
    }

    protected function getAbsolutePath($relativePath) {
        return plugin_dir_path($this->pluginFile) . $relativePath;
    }

    protected function isPluginFile($absolutePath) {
        return ($absolutePath === $this->pluginFile) || (strpos($absolutePath, $this->pluginFile) === 0);
    }

    protected function getAbsoluteUrl($relativePath) {
        return plugins_url($relativePath, $this->pluginFile);
    }

    protected function getPluginSlug() {
        return $this->slug;
    }

    protected function getPluginFile() {
        return $this->pluginFile;
    }

    protected function getPluginDirectory() {
        return plugin_dir_path($this->pluginFile);
    }

    protected function getPluginUrl() {
        return plugin_dir_url($this->pluginFile);
    }
}
