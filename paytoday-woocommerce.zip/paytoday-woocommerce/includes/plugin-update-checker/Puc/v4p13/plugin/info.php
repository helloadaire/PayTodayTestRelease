<?php

class Puc_v4p13_Plugin_Info {
    public $name = '';
    public $slug = '';
    public $version = '';
    public $homepage = '';
    public $sections = array();
    public $banners = array();
    public $translations = array();

    public $download_url = '';
    public $requires = '';
    public $tested = '';
    public $requires_php = '';
    public $last_updated = '';
    public $upgrade_notice = '';

    public $author = '';
    public $author_homepage = '';
    public $donate_link = '';

    public $rating = 0;
    public $num_ratings = 0;
    public $downloaded = 0;
    public $active_installs = 0;

    public $id = 0;
    public $filename = '';

    public function __construct($filename = '') {
        $this->filename = $filename;
    }
}
