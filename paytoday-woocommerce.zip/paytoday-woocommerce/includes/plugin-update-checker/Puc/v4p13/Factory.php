<?php

abstract class Puc_v4_Factory {
    protected static $classVersion = '4.13';
    protected static $minimumCompatibleVersion = '4.0';
    private static $registeredFactories = array();

    /**
     * Create a new update checker instance.
     *
     * @param string $metadataUrl The URL of the plugin's metadata file.
     * @param string $pluginFile The path to the plugin file.
     * @param string $slug The plugin's 'slug'. If not specified, the filename part of $pluginFile sans '.php' will be used as the slug.
     * @param integer $checkPeriod How often to check for updates (in hours). Defaults to checking every 12 hours. Set to 0 to disable automatic update checks.
     * @param string $optionName Where to store book-keeping info about update checks. Defaults to 'external_updates-$slug'.
     * @param string $muPluginFile The plugin file relative to the mu-plugins directory.
     * @return Puc_v4p13_Plugin_UpdateChecker
     */
    public static function buildUpdateChecker($metadataUrl, $pluginFile, $slug = '', $checkPeriod = 12, $optionName = '', $muPluginFile = '') {
        $class = self::getCompatibleClassVersion(__FUNCTION__);
        if ($class) {
            return new $class($metadataUrl, $pluginFile, $slug, $checkPeriod, $optionName, $muPluginFile);
        }
        return null;
    }

    /**
     * Create a new theme update checker instance.
     *
     * @param string $metadataUrl Theme metadata URL.
     * @param string $themeStylesheet Theme stylesheet directory name.
     * @param string $customSlug Theme slug.
     * @param integer $checkPeriod How often to check for updates (in hours). Defaults to checking every 12 hours. Set to 0 to disable automatic update checks.
     * @param string $optionName Where to store book-keeping info about update checks. Defaults to 'external_updates-$slug'.
     * @param string $cssUrl Theme stylesheet URL.
     * @return Puc_v4p13_Theme_UpdateChecker
     */
    public static function buildThemeUpdateChecker($metadataUrl, $themeStylesheet, $customSlug = '', $checkPeriod = 12, $optionName = '', $cssUrl = '') {
        $class = self::getCompatibleClassVersion(__FUNCTION__);
        if ($class) {
            return new $class($metadataUrl, $themeStylesheet, $customSlug, $checkPeriod, $optionName, $cssUrl);
        }
        return null;
    }

    /**
     * Create a new VCS update checker instance.
     *
     * @param string $apiClass The name of the API class.
     * @param string $username Username.
     * @param string $repositoryName Repository name.
     * @param string $pluginFile Path to the plugin file.
     * @param string $slug Plugin slug.
     * @param integer $checkPeriod How often to check for updates (in hours). Defaults to checking every 12 hours. Set to 0 to disable automatic update checks.
     * @param string $optionName Where to store book-keeping info about update checks. Defaults to 'external_updates-$slug'.
     * @param string $muPluginFile The plugin file relative to the mu-plugins directory.
     * @return Puc_v4p13_Vcs_PluginUpdateChecker
     */
    public static function buildVcsPluginChecker($apiClass, $username, $repositoryName, $pluginFile, $slug = '', $checkPeriod = 12, $optionName = '', $muPluginFile = '') {
        $class = self::getCompatibleClassVersion(__FUNCTION__);
        if ($class) {
            return new $class($apiClass, $username, $repositoryName, $pluginFile, $slug, $checkPeriod, $optionName, $muPluginFile);
        }
        return null;
    }

    /**
     * Create a new VCS theme update checker instance.
     *
     * @param string $apiClass The name of the API class.
     * @param string $username Username.
     * @param string $repositoryName Repository name.
     * @param string $themeStylesheet Theme stylesheet.
     * @param string $customSlug Theme slug.
     * @param integer $checkPeriod How often to check for updates (in hours). Defaults to checking every 12 hours. Set to 0 to disable automatic update checks.
     * @param string $optionName Where to store book-keeping info about update checks. Defaults to 'external_updates-$slug'.
     * @param string $cssUrl Theme stylesheet URL.
     * @return Puc_v4p13_Vcs_ThemeUpdateChecker
     */
    public static function buildVcsThemeChecker($apiClass, $username, $repositoryName, $themeStylesheet, $customSlug = '', $checkPeriod = 12, $optionName = '', $cssUrl = '') {
        $class = self::getCompatibleClassVersion(__FUNCTION__);
        if ($class) {
            return new $class($apiClass, $username, $repositoryName, $themeStylesheet, $customSlug, $checkPeriod, $optionName, $cssUrl);
        }
        return null;
    }

    /**
     * Register a custom factory class.
     *
     * @param string $factoryClass The factory class name.
     * @param string $version The version of the factory class.
     */
    public static function addVersion($factoryClass, $version) {
        self::$registeredFactories[$version] = $factoryClass;
    }

    /**
     * Get the highest compatible factory class.
     *
     * @param string $method The method name.
     * @return string|null
     */
    protected static function getCompatibleClassVersion($method) {
        // Check if we have a compatible version registered
        foreach (self::$registeredFactories as $version => $class) {
            if (version_compare($version, self::$minimumCompatibleVersion, '>=')) {
                return $class;
            }
        }
        return null;
    }
}
