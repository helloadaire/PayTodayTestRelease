<?php

abstract class Puc_v4p13_UpdateChecker {
    protected $filterSuffix = '';
    protected $updateTransient = '';
    protected $transientType = '';
    protected $optionName = '';

    protected $metadataUrl = '';
    protected $pluginAbsolutePath = '';
    protected $pluginFile = '';
    protected $slug = '';
    protected $checkPeriod = 12;
    protected $optionName = '';
    protected $muPluginFile = '';
    protected $cronHook = null;
    protected $debugMode = false;

    public function __construct($metadataUrl, $pluginFile, $slug = '', $checkPeriod = 12, $optionName = '', $muPluginFile = '') {
        $this->metadataUrl = $metadataUrl;
        $this->pluginFile = $pluginFile;
        $this->pluginAbsolutePath = $pluginFile;
        $this->slug = $slug;
        $this->checkPeriod = $checkPeriod;
        $this->optionName = $optionName;
        $this->muPluginFile = $muPluginFile;

        // If no slug was specified, use the name of the plugin file
        if (empty($this->slug)) {
            $this->slug = basename($this->pluginFile, '.php');
        }

        // If no option name was specified, use the slug
        if (empty($this->optionName)) {
            $this->optionName = 'external_updates-' . $this->slug;
        }

        $this->installHooks();
    }

    protected function installHooks() {
        // Check for updates when WordPress checks for updates
        add_filter('pre_set_site_transient_' . $this->updateTransient, array($this, 'checkForUpdates'));

        // Check for updates when the admin visits the "Dashboard -> Updates" page
        add_action('load-update-core.php', array($this, 'checkForUpdates'));

        // Check for updates when the admin visits the "Plugins" page
        add_action('load-plugins.php', array($this, 'checkForUpdates'));

        // Check for updates when the admin visits the "Plugins -> Installed Plugins" page
        add_action('load-update.php', array($this, 'checkForUpdates'));

        // This is for backwards compatibility
        add_action('admin_init', array($this, 'checkForUpdates'));

        // Set up the WordPress cron to check for updates
        add_action($this->getCronHookName(), array($this, 'checkForUpdates'));

        // Deactivation
        register_deactivation_hook($this->pluginFile, array($this, 'onDeactivation'));
    }

    public function checkForUpdates($transient = null) {
        if (empty($transient)) {
            $transient = $this->getUpdateListTransient();
        }

        $update = $this->requestUpdate();
        if (is_wp_error($update)) {
            return $transient;
        }

        if ($update !== null) {
            $transient = $this->addUpdateToList($transient, $update);
        }

        $this->setUpdateListTransient($transient);
        return $transient;
    }

    protected function addUpdateToList($transient, $update) {
        if ($transient === false) {
            $transient = new stdClass();
            $transient->last_checked = time();
            $transient->response = array();
        }

        $transient->response[$update->id] = $update;
        return $transient;
    }

    public function requestUpdate($queryArgs = array()) {
        $url = add_query_arg($queryArgs, $this->metadataUrl);
        $result = wp_remote_get($url, array(
            'timeout' => 15,
        ));

        if (is_wp_error($result)) {
            return $result;
        }

        $responseCode = wp_remote_retrieve_response_code($result);
        if ($responseCode !== 200) {
            return new WP_Error(
                'puc-http-error',
                sprintf('HTTP error %d while checking for updates.', $responseCode)
            );
        }

        $update = $this->parseMetadataResponse(wp_remote_retrieve_body($result));
        if (is_wp_error($update)) {
            return $update;
        }

        return $update;
    }

    protected function parseMetadataResponse($response) {
        $pluginInfo = new Puc_v4p13_Plugin_Info();
        $pluginInfo->filename = $this->pluginFile;
        $pluginInfo->slug = $this->slug;

        return $pluginInfo;
    }

    public function getUpdate($force = false) {
        $transient = $this->getUpdateListTransient();
        if (empty($transient->response)) {
            return null;
        }

        $update = $transient->response[$this->pluginFile];
        if (empty($update)) {
            return null;
        }

        return $update;
    }

    protected function getUpdateListTransient() {
        return get_site_transient($this->updateTransient);
    }

    protected function setUpdateListTransient($value) {
        set_site_transient($this->updateTransient, $value, 3 * HOUR_IN_SECONDS);
    }

    protected function getCronHookName() {
        return 'check-plugin-updates-' . $this->slug;
    }

    public function onDeactivation() {
        wp_clear_scheduled_hook($this->getCronHookName());
    }

    public function getInstalledVersion() {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . '/wp-admin/includes/plugin.php');
        }
        $pluginHeader = get_plugin_data($this->pluginFile, false, false);
        return array_key_exists('Version', $pluginHeader) ? $pluginHeader['Version'] : '';
    }
}
