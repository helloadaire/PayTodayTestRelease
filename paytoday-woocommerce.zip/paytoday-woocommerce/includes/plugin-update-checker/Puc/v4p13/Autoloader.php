<?php

class Puc_v4p13_Autoloader {
    private $prefix = '';
    private $rootDir = '';
    private $libraryDir = '';

    public function __construct() {
        $this->rootDir = dirname(dirname(__FILE__)) . '/';
        $this->libraryDir = $this->rootDir . 'Puc/v4p13/';
        
        spl_autoload_register(array($this, 'autoload'));
    }

    public function autoload($className) {
        // Only handle classes that start with our prefix
        if (strpos($className, 'Puc_v4p13_') !== 0) {
            return;
        }

        $path = $this->getClassPath($className);
        if (file_exists($path)) {
            require_once $path;
        }
    }

    private function getClassPath($className) {
        // Remove the prefix
        $relativeClass = substr($className, strlen('Puc_v4p13_'));

        // Convert class name format to file path
        $path = str_replace('_', '/', $relativeClass);
        $path = strtolower($path);

        return $this->libraryDir . $path . '.php';
    }
}
