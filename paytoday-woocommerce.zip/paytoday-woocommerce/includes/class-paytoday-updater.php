<?php
/**
 * PayToday Plugin Update Checker
 *
 * @package PayToday
 * @since 7.3.4
 */

defined('ABSPATH') || exit;

/**
 * Handles plugin updates using Plugin Update Checker library
 */
class PayToday_Updater {

    /**
     * Plugin slug
     *
     * @var string
     */
    private $plugin_slug = 'paytoday-woocommerce';

    /**
     * Plugin file path
     *
     * @var string
     */
    private $plugin_file;

    /**
     * Update checker instance
     *
     * @var object
     */
    private $update_checker;

    /**
     * Constructor
     *
     * @param string $plugin_file Plugin file path.
     */
    public function __construct($plugin_file) {
        $this->plugin_file = $plugin_file;
        $this->init_update_checker();
    }

    /**
     * Initialize the update checker
     */
    private function init_update_checker() {
        // Load Plugin Update Checker if not already loaded
        if (!class_exists('Puc_v4_Factory')) {
            $this->load_plugin_update_checker();
        }

        // Initialize update checker
        $this->update_checker = Puc_v4_Factory::buildUpdateChecker(
            $this->get_update_url(),
            $this->plugin_file,
            $this->plugin_slug
        );

        // Set authentication if needed
        $this->setup_authentication();

        // Add filters for custom update data
        $this->add_update_filters();
    }

    /**
     * Load Plugin Update Checker library
     */
    private function load_plugin_update_checker() {
        $puc_path = plugin_dir_path($this->plugin_file) . 'includes/plugin-update-checker/plugin-update-checker.php';
        
        if (file_exists($puc_path)) {
            require_once $puc_path;
        } else {
            // Fallback: try to load from vendor directory
            $vendor_path = plugin_dir_path($this->plugin_file) . 'vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';
            if (file_exists($vendor_path)) {
                require_once $vendor_path;
            }
        }
    }

    /**
     * Get update URL
     *
     * @return string
     */
    private function get_update_url() {
        // You can customize this URL to point to your update server
        // For now, we'll use a placeholder that you can update
        return apply_filters('paytoday_update_url', 'https://raw.githubusercontent.com/douglasadaire/test-paytoday-update/master/update-info.json');
    }

    /**
     * Setup authentication for private repositories
     */
    private function setup_authentication() {
        // If you have a private repository, you can add authentication here
        // Example for GitHub private repo:
        /*
        $this->update_checker->setAuthentication('your-github-token');
        */
    }

    /**
     * Add filters for custom update data
     */
    private function add_update_filters() {
        // Customize the update notification
        add_filter('puc_pre_inject_update-' . $this->plugin_slug, array($this, 'customize_update_data'), 10, 2);
        
        // Add custom update message
        add_filter('puc_manual_check_link-' . $this->plugin_slug, array($this, 'custom_manual_check_link'));
    }

    /**
     * Customize update data
     *
     * @param object $update Update object.
     * @param object $api_response API response.
     * @return object
     */
    public function customize_update_data($update, $api_response) {
        if ($update && isset($api_response->body)) {
            $data = json_decode($api_response->body);
            
            if ($data && isset($data->sections)) {
                // Customize sections if needed
                if (isset($data->sections->changelog)) {
                    $update->sections['changelog'] = $data->sections->changelog;
                }
                
                if (isset($data->sections->description)) {
                    $update->sections['description'] = $data->sections->description;
                }
            }
        }
        
        return $update;
    }

    /**
     * Custom manual check link
     *
     * @param string $link Manual check link.
     * @return string
     */
    public function custom_manual_check_link($link) {
        return sprintf(
            '<a href="%s" class="button button-secondary">%s</a>',
            esc_url(add_query_arg('action', 'check-plugin-updates', admin_url('admin-ajax.php'))),
            __('Check for Updates', 'paytoday-woocommerce')
        );
    }

    /**
     * Get update checker instance
     *
     * @return object
     */
    public function get_update_checker() {
        return $this->update_checker;
    }

    /**
     * Check for updates manually
     */
    public function manual_update_check() {
        if ($this->update_checker) {
            $this->update_checker->checkForUpdates();
        }
    }

    /**
     * Get plugin information
     *
     * @return array
     */
    public function get_plugin_info() {
        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        return get_plugin_data($this->plugin_file);
    }

    /**
     * Get current version
     *
     * @return string
     */
    public function get_current_version() {
        $plugin_data = $this->get_plugin_info();
        return isset($plugin_data['Version']) ? $plugin_data['Version'] : '0.0.0';
    }

    /**
     * Check if update is available
     *
     * @return bool
     */
    public function has_update() {
        if ($this->update_checker) {
            $update = $this->update_checker->getUpdate();
            return $update !== null;
        }
        
        return false;
    }

    /**
     * Get update information
     *
     * @return object|null
     */
    public function get_update_info() {
        if ($this->update_checker) {
            return $this->update_checker->getUpdate();
        }
        
        return null;
    }
}
