<?php
/**
 * Plugin Name: PayToday for WooCommerce
 * Plugin URI: https://paytoday.com
 * Description: Official PayToday payment gateway for WooCommerce using JavaScript SDK.
 * Version: 7.3.5
 * Author: PayToday
 * Author URI: https://paytoday.com
 * License: GPL-3.0+
 * Text Domain: paytoday-woocommerce
 * WC requires at least: 7.0
 * WC tested up to: 8.2
 * Requires PHP: 8.1
 */

defined('ABSPATH') || exit;

require 'plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://raw.githubusercontent.com/helloadaire/PayToday-Update-JSON/master/update-info.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'paytoday-woocommerce'
);

// Safety check to prevent direct file access
if (!defined('WPINC')) {
    die;
}

register_activation_hook(__FILE__, function() {
    flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, function() {
    flush_rewrite_rules();
});

// HPOS Compatibility Declaration with safety checks
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        try {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
        } catch (Exception $e) {
            error_log('PayToday HPOS compatibility declaration failed: ' . $e->getMessage());
        }
    }
});

// Load translations with error handling
add_action('plugins_loaded', function() {
    try {
        load_plugin_textdomain('paytoday-woocommerce', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    } catch (Exception $e) {
        error_log('PayToday translation loading failed: ' . $e->getMessage());
    }
});

// Register gateway with safety checks
add_filter('woocommerce_payment_gateways', function($gateways) {
    if (!function_exists('wc_get_logger')) {
        error_log('PayToday: WooCommerce not loaded, cannot register gateway');
        return $gateways;
    }
    
    try {
        $gateways[] = 'WC_PayToday_Gateway';
    } catch (Exception $e) {
        error_log('PayToday gateway registration failed: ' . $e->getMessage());
    }
    
    return $gateways;
});

// Main gateway class with all safety checks
add_action('plugins_loaded', function() {
    if (!class_exists('WC_Payment_Gateway')) {
        error_log('PayToday: WooCommerce Payment Gateway class not found');
        return;
    }

    // Blocks support class with conditional loading
    if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        class WC_PayToday_Blocks_Support extends Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
            protected $gateway;

            public function __construct() {
                $this->name = 'paytoday';
                $this->gateway = new WC_PayToday_Gateway();
            }

            public function initialize() {
                try {
                    $this->settings = $this->gateway->settings;
                } catch (Exception $e) {
                    error_log('PayToday blocks initialization failed: ' . $e->getMessage());
                }
            }

            public function is_active() {
                try {
                    return $this->gateway->is_available();
                } catch (Exception $e) {
                    error_log('PayToday blocks is_active check failed: ' . $e->getMessage());
                    return false;
                }
            }

            public function get_payment_method_script_handles() {
                try {
                    $script_url = plugins_url('assets/js/blocks/paytoday.js', __FILE__);
                    if (!wp_script_is('wc-blocks-registry', 'registered')) {
                        error_log('PayToday: WC Blocks registry not available');
                        return [];
                    }

                    wp_register_script(
                        'wc-paytoday-blocks',
                        $script_url,
                        ['wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities'],
                        WC_PayToday_Gateway::PLUGIN_VERSION,
                        true
                    );
                    return ['wc-paytoday-blocks'];
                } catch (Exception $e) {
                    error_log('PayToday blocks script registration failed: ' . $e->getMessage());
                    return [];
                }
            }

            public function get_payment_method_data() {
                try {
                    return [
                        'title' => $this->gateway->title,
                        'description' => $this->gateway->description,
                        'icon' => $this->gateway->icon,
                        'supports' => $this->gateway->supports,
                        'settings' => $this->gateway->settings,
                        'params' => [
                            'shop_key' => $this->gateway->shop_key,
                            'shop_handle' => $this->gateway->shop_handle,
                            'private_key' => $this->gateway->private_key,
                            'is_enabled' => $this->gateway->enabled,
                            'environment' => $this->gateway->environment
                        ]
                    ];
                } catch (Exception $e) {
                    error_log('PayToday blocks data preparation failed: ' . $e->getMessage());
                    return [];
                }
            }
        }

        // Register blocks support
        add_action('woocommerce_blocks_loaded', function() {
            try {
                if (!class_exists('Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry')) {
                    error_log('PayToday: WC Blocks PaymentMethodRegistry not available');
                    return;
                }

                add_action(
                    'woocommerce_blocks_payment_method_type_registration',
                    function($payment_method_registry) {
                        try {
                            $payment_method_registry->register(new WC_PayToday_Blocks_Support());
                        } catch (Exception $e) {
                            error_log('PayToday blocks registration failed: ' . $e->getMessage());
                        }
                    }
                );
            } catch (Exception $e) {
                error_log('PayToday blocks loaded action failed: ' . $e->getMessage());
            }
        });
    }

    #[\AllowDynamicProperties]
    class WC_PayToday_Gateway extends WC_Payment_Gateway {
        const GATEWAY_ID = 'paytoday';
        const SDK_VERSION = '12.12.2024';
        const PLUGIN_VERSION = '7.3.4';

        public $enabled;
        public $title;
        public $description;
        public $environment;
        public $enable_tokenization;
        public $shop_key;
        public $shop_handle;
        public $private_key;
        public $return_url;

        public function __construct() {
            try {
                $this->id = self::GATEWAY_ID;
                $this->icon = apply_filters('woocommerce_paytoday_icon', plugins_url('assets/images/paytoday-logo.png', __FILE__));
                $this->has_fields = true;
                $this->method_title = __('PayToday', 'paytoday-woocommerce');
                $this->method_description = __('Accept payments via PayToday secure payment gateway.', 'paytoday-woocommerce');
                $this->supports = [
                    'products',
                    'refunds',
                    'tokenization',
                    'add_payment_method'
                ];
                
                $this->init_form_fields();
                $this->init_settings();
                
                // Initialize settings with defaults
                $this->enabled = $this->get_option('enabled', 'no');
                $this->title = $this->get_option('title', __('PayToday', 'paytoday-woocommerce'));
                $this->description = $this->get_option('description', '');
                $this->shop_key = $this->get_option('shop_key');
                $this->shop_handle = $this->get_option('shop_handle');
                $this->private_key = $this->get_option('private_key', 'DvzOMtOpC4215y7ClqpM');
                $this->environment = $this->get_option('environment', 'sandbox');
                $this->debug = 'yes' === $this->get_option('debug', 'no');
                $this->enable_tokenization = 'yes' === $this->get_option('enable_tokenization', 'no');
                
                // Hooks with validation
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
                add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
                add_action('woocommerce_api_paytoday_webhook', [$this, 'handle_webhook']);
                add_action('woocommerce_receipt_' . $this->id, [$this, 'receipt_page']);
                add_action('woocommerce_api_paytoday_return', [$this, 'handle_return']);
                
            } catch (Exception $e) {
                error_log('PayToday gateway construction failed: ' . $e->getMessage());
            }
        }

        public function handle_return() {
            try {
                $order_id = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;
                $status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
                $reference = isset($_GET['reference']) ? sanitize_text_field($_GET['reference']) : '';
                $invoice_number = isset($_GET['invoice_number']) ? sanitize_text_field($_GET['invoice_number']) : '';
                $reference_number = isset($_GET['reference_number']) ? sanitize_text_field($_GET['reference_number']) : '';

                if (!$order_id) {
                    throw new Exception('Missing order ID');
                }

                $order = wc_get_order($order_id);
                
                if (!$order) {
                    throw new Exception('Invalid order');
                }

                if ($status === 'success') {
                    // Payment was successful
                    $order->payment_complete($reference);
                    $order->add_order_note(
                        sprintf(
                            __('PayToday payment completed. Reference: %s, Invoice: %s, Ref Number: %s', 'paytoday-woocommerce'),
                            $reference,
                            $invoice_number,
                            $reference_number
                        )
                    );
                    
                    // Redirect to thank you page
                    wp_redirect($this->get_return_url($order));
                    exit;
                } else {
                    // Payment failed
                    $order->update_status(
                        'failed',
                        sprintf(
                            __('PayToday payment declined. Reference: %s, Invoice: %s, Ref Number: %s', 'paytoday-woocommerce'),
                            $reference,
                            $invoice_number,
                            $reference_number
                        )
                    );
                    
                    // Redirect back to checkout with error
                    wc_add_notice(__('Payment was declined. Please try again.', 'paytoday-woocommerce'), 'error');
                    wp_redirect(wc_get_checkout_url());
                    exit;
                }
            } catch (Exception $e) {
                $this->log('Return URL processing failed: ' . $e->getMessage());
                wp_redirect(wc_get_checkout_url());
                exit;
            }
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'paytoday-woocommerce'),
                    'type' => 'checkbox',
                    'label' => __('Enable PayToday Gateway', 'paytoday-woocommerce'),
                ),
                'title' => array(
                    'title' => __('Title', 'paytoday-woocommerce'),
                    'type' => 'text',
                    'description' => __('Payment method title that customers see.', 'paytoday-woocommerce'),
                    'desc_tip' => true
                ),
                'description' => array(
                    'title' => __('Description', 'paytoday-woocommerce'),
                    'type' => 'textarea',
                    'description' => __('Payment method description.', 'paytoday-woocommerce'),
                    'desc_tip' => true
                ),
                'environment' => array(
                    'title' => __('Environment', 'paytoday-woocommerce'),
                    'type' => 'select',
                    'options' => [
                        'production' => __('Production', 'paytoday-woocommerce'),
                    ],
                    'default' => 'production',
                    'desc_tip' => true
                ),
                'shop_key' => array(
                    'title' => __('Shop Key', 'paytoday-woocommerce'),
                    'type' => 'text',
                    'description' => __('Your PayToday Shop Key', 'paytoday-woocommerce'),
                    'desc_tip' => true
                ),
                'shop_handle' => array(
                    'title' => __('Shop Handle', 'paytoday-woocommerce'),
                    'type' => 'text',
                    'description' => __('Your PayToday Shop Handle', 'paytoday-woocommerce'),
                    'desc_tip' => true
                ),
                'private_key' => array(
                    'title' => __('Private Key', 'paytoday-woocommerce'),
                    'type' => 'password',
                    'description' => __('Your PayToday Private Key for webhook verification', 'paytoday-woocommerce'),
                    'default' => 'DvzOMtOpC4215y7ClqpM',
                    'desc_tip' => true
                ),
                'enable_tokenization' => array(
                    'title' => __('Tokenization', 'paytoday-woocommerce'),
                    'label' => __('Enable tokenization', 'paytoday-woocommerce'),
                    'type' => 'checkbox',
                    'description' => __('Allow customers to save payment methods for future purchases.', 'paytoday-woocommerce'),
                    'default' => 'no',
                    'desc_tip' => true,
                ),
                'debug' => array(
                    'title' => __('Debug Log', 'paytoday-woocommerce'),
                    'type' => 'checkbox',
                    'label' => __('Enable logging', 'paytoday-woocommerce'),
                    'default' => 'no',
                    'description' => sprintf(
                        __('Log PayToday events in %s', 'paytoday-woocommerce'),
                        '<code>' . WC_Log_Handler_File::get_log_file_path('paytoday') . '</code>'
                    )
                )
            );
        }

        public function enqueue_scripts() {
            try {
                if (!is_checkout() && !is_add_payment_method_page() && !isset($_GET['pay_for_order'])) {
                    return;
                }

                // Enqueue SDK with fallback
                $sdk_url = 'https://nedbankstorage.blob.core.windows.net/nedbankclouddatadisk/staticazure/web/sdk/paytoday-sdk.js';
                wp_enqueue_script(
                    'paytoday-sdk',
                    $sdk_url,
                    [],
                    self::SDK_VERSION,
                    true
                );

                // Enqueue integration script with dependency check
                $integration_script = plugins_url('assets/js/paytoday-woocommerce.js', __FILE__);
                if (file_exists(dirname(__FILE__) . '/assets/js/paytoday-woocommerce.js')) {
                    wp_enqueue_script(
                        'paytoday-woocommerce',
                        $integration_script,
                        ['jquery', 'paytoday-sdk', 'wc-checkout'],
                        self::PLUGIN_VERSION,
                        true
                    );

                    // Localize script data with validation
                    $localized_data = [
                        'shop_key' => $this->shop_key,
                        'shop_handle' => $this->shop_handle,
                        'private_key' => $this->private_key,
                        'is_enabled' => $this->enabled,
                        'environment' => $this->environment,
                        'store_api_nonce' => wp_create_nonce('wc_store_api'),
                        'ajax_url' => WC_AJAX::get_endpoint('%%endpoint%%'),
                        'nonce' => wp_create_nonce('paytoday-process-payment'),
                        'is_checkout' => is_checkout(),
                        'is_pay_for_order' => isset($_GET['pay_for_order']),
                        'is_add_payment_method' => is_add_payment_method_page(),
                        'i18n' => [
                            'processing' => __('Processing payment...', 'paytoday-woocommerce'),
                            'error' => __('Payment error. Please try again.', 'paytoday-woocommerce'),
                            'save_payment' => __('Save payment method for future use', 'paytoday-woocommerce')
                        ]
                    ];

                    wp_localize_script('paytoday-woocommerce', 'paytoday_params', $localized_data);
                }

                // Add CSS with file existence check
                $css_path = dirname(__FILE__) . '/assets/css/paytoday-woocommerce.css';
                if (file_exists($css_path)) {
                    wp_enqueue_style(
                        'paytoday-woocommerce',
                        plugins_url('assets/css/paytoday-woocommerce.css', __FILE__),
                        [],
                        self::PLUGIN_VERSION
                    );
                }
            } catch (Exception $e) {
                error_log('PayToday script enqueue failed: ' . $e->getMessage());
            }
        }

        public function payment_fields() {
            try {
                parent::payment_fields();
                
                echo '<div id="paytoday-payment-container" class="paytoday-payment-container"></div>';
                
                if ($this->supports('tokenization') && $this->enable_tokenization && is_checkout()) {
                    $this->tokenization_script();
                    $this->saved_payment_methods();
                    $this->save_payment_method_checkbox();
                }
            } catch (Exception $e) {
                error_log('PayToday payment fields rendering failed: ' . $e->getMessage());
                echo '<p>' . __('Error loading payment form. Please try again.', 'paytoday-woocommerce') . '</p>';
            }
        }

        public function validate_fields() {
            return true;
        }

        public function process_payment($order_id) {
            try {
                $order = wc_get_order($order_id);
                
                if (!$order) {
                    $this->log('Error: Could not load order #' . $order_id);
                    throw new Exception(__('Payment error: Could not load order.', 'paytoday-woocommerce'));
                }

                // Mark as pending (payment will be completed via return URL)
                $order->update_status('pending', __('Awaiting PayToday payment', 'paytoday-woocommerce'));

                // Return success with redirect
                return [
                    'result' => 'success',
                    'redirect' => $order->get_checkout_payment_url(true)
                ];
            } catch (Exception $e) {
                $this->log('Payment processing failed: ' . $e->getMessage());
                wc_add_notice(__('Payment error: ', 'paytoday-woocommerce') . $e->getMessage(), 'error');
                return [
                    'result' => 'failure'
                ];
            }
        }

        protected function process_token_payment($order_id, $token_id) {
            try {
                $order = wc_get_order($order_id);
                $token = WC_Payment_Tokens::get($token_id);
                
                if (!$token || $token->get_user_id() !== get_current_user_id()) {
                    throw new Exception(__('Invalid payment method. Please try again.', 'paytoday-woocommerce'));
                }

                // Process payment with token here
                // This would call PayToday API with the token
                
                $order->payment_complete();
                WC()->cart->empty_cart();
                
                return [
                    'result' => 'success',
                    'redirect' => $this->get_return_url($order)
                ];
            } catch (Exception $e) {
                $this->log('Token payment processing failed: ' . $e->getMessage());
                wc_add_notice(__('Token payment error: ', 'paytoday-woocommerce') . $e->getMessage(), 'error');
                return [
                    'result' => 'failure'
                ];
            }
        }

        public function process_refund($order_id, $amount = null, $reason = '') {
            try {
                $order = wc_get_order($order_id);
                
                if (!$order) {
                    $this->log('Refund failed: Could not load order #' . $order_id);
                    return new WP_Error('error', __('Could not load order.', 'paytoday-woocommerce'));
                }

                // Implement actual refund logic here via PayToday API
                // This is a placeholder - you would need to implement the actual API call
                $refund_success = $this->process_api_refund($order, $amount, $reason);
                
                if ($refund_success) {
                    $order->add_order_note(
                        sprintf(
                            __('Refunded %1$s via PayToday. Reason: %2$s', 'paytoday-woocommerce'),
                            wc_price($amount),
                            $reason
                        )
                    );
                    
                    if ($this->debug) {
                        $this->log("Refund processed: Order #$order_id | Amount: $amount | Reason: $reason");
                    }
                    
                    return true;
                }
                
                return new WP_Error('error', __('Refund failed.', 'paytoday-woocommerce'));
            } catch (Exception $e) {
                $this->log('Refund processing failed: ' . $e->getMessage());
                return new WP_Error('error', $e->getMessage());
            }
        }

        protected function process_api_refund($order, $amount, $reason) {
            // Implement actual PayToday API refund logic here
            // This should return true on success, false on failure
            
            // For now, we'll simulate success in sandbox mode
            if ($this->environment === 'sandbox') {
                return true;
            }
            
            return false;
        }

        public function receipt_page($order_id) {
            try {
                echo '<div id="paytoday-payment-process"></div>';
            } catch (Exception $e) {
                error_log('PayToday receipt page rendering failed: ' . $e->getMessage());
                echo '<p>' . __('Error loading payment processor. Please try again.', 'paytoday-woocommerce') . '</p>';
            }
        }

        public function handle_webhook() {
            try {
                $payload = @file_get_contents('php://input');
                if ($payload === false) {
                    status_header(400);
                    exit;
                }

                $signature = isset($_SERVER['HTTP_X_PAYTODAY_SIGNATURE']) ? $_SERVER['HTTP_X_PAYTODAY_SIGNATURE'] : '';
                
                // Verify signature
                if (!$this->verify_webhook_signature($payload, $signature)) {
                    status_header(400);
                    exit;
                }

                $data = json_decode($payload, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    status_header(400);
                    exit;
                }

                if (!isset($data['event'], $data['data'])) {
                    status_header(400);
                    exit;
                }

                $this->log('Webhook received: ' . print_r($data, true));

                switch ($data['event']) {
                    case 'payment.success':
                        $this->handle_successful_payment($data['data']);
                        break;
                    case 'payment.failed':
                        $this->handle_failed_payment($data['data']);
                        break;
                    case 'payment.token_created':
                        $this->handle_token_created($data['data']);
                        break;
                    default:
                        $this->log('Unknown webhook event: ' . $data['event']);
                        status_header(400);
                        exit;
                }

                status_header(200);
                exit;
            } catch (Exception $e) {
                $this->log('Webhook processing failed: ' . $e->getMessage());
                status_header(500);
                exit;
            }
        }

        protected function verify_webhook_signature($payload, $signature) {
            try {
                if (empty($this->private_key) || empty($signature)) {
                    return false;
                }
                
                $computed_signature = hash_hmac('sha256', $payload, $this->private_key);
                return hash_equals($computed_signature, $signature);
            } catch (Exception $e) {
                $this->log('Signature verification failed: ' . $e->getMessage());
                return false;
            }
        }

        protected function handle_successful_payment($data) {
            try {
                if (empty($data['invoice_number'])) {
                    throw new Exception('Missing invoice number');
                }

                $order = wc_get_order($data['invoice_number']);
                
                if (!$order || $order->get_payment_method() !== $this->id) {
                    throw new Exception('Invalid order');
                }

                if ($order->has_status(['processing', 'completed'])) {
                    return;
                }

                // Complete payment
                $order->payment_complete($data['transaction_id']);
                $order->add_order_note(
                    __('PayToday payment completed. Transaction ID: ', 'paytoday-woocommerce') . $data['transaction_id']
                );

                $this->log('Payment completed for order #' . $order->get_id());
            } catch (Exception $e) {
                $this->log('Successful payment handling failed: ' . $e->getMessage());
                throw $e;
            }
        }

        protected function handle_failed_payment($data) {
            try {
                if (empty($data['invoice_number'])) {
                    throw new Exception('Missing invoice number');
                }

                $order = wc_get_order($data['invoice_number']);
                
                if (!$order || $order->get_payment_method() !== $this->id) {
                    throw new Exception('Invalid order');
                }

                if ($order->has_status('failed')) {
                    return;
                }

                $order->update_status(
                    'failed',
                    __('PayToday payment failed. Reason: ', 'paytoday-woocommerce') . 
                    ($data['failure_reason'] ?? __('Unknown', 'paytoday-woocommerce'))
                );

                $this->log('Payment failed for order #' . $order->get_id());
            } catch (Exception $e) {
                $this->log('Failed payment handling failed: ' . $e->getMessage());
                throw $e;
            }
        }

        protected function handle_token_created($data) {
            try {
                if (!is_user_logged_in() || empty($data['token']) || empty($data['payment_method_id'])) {
                    return;
                }

                $user_id = get_current_user_id();
                $token_value = sanitize_text_field($data['token']);
                
                // Check if token already exists
                if (WC_Payment_Tokens::token_exists($token_value, $user_id)) {
                    return;
                }

                $token = new WC_Payment_Token_CC();
                $token->set_token($token_value);
                $token->set_gateway_id($this->id);
                $token->set_user_id($user_id);
                $token->set_last4(substr(sanitize_text_field($data['payment_method_id']), -4));
                
                // Use actual expiry if available, otherwise use defaults
                if (!empty($data['exp_month']) && !empty($data['exp_year'])) {
                    $token->set_expiry_month(sanitize_text_field($data['exp_month']));
                    $token->set_expiry_year(sanitize_text_field($data['exp_year']));
                } else {
                    $token->set_expiry_month('12');
                    $token->set_expiry_year(date('Y') + 5);
                }
                
                // Use actual card type if available
                $card_type = !empty($data['card_type']) ? strtolower(sanitize_text_field($data['card_type'])) : 'credit';
                $token->set_card_type($card_type);
                
                // Mark as default if this is the first token
                $tokens = WC_Payment_Tokens::get_customer_tokens($user_id, $this->id);
                $token->set_default(empty($tokens));
                
                $token->save();
                
                $this->log('Token created for user #' . $user_id);
            } catch (Exception $e) {
                $this->log('Token creation failed: ' . $e->getMessage());
            }
        }

        public function is_available() {
            try {
                $is_available = parent::is_available();
                
                return $is_available && 
                       !empty($this->shop_key) && 
                       !empty($this->shop_handle);
            } catch (Exception $e) {
                $this->log('Availability check failed: ' . $e->getMessage());
                return false;
            }
        }

        protected function has_valid_token() {
            try {
                if (!is_user_logged_in() || !$this->enable_tokenization) {
                    return false;
                }
                
                $tokens = WC_Payment_Tokens::get_customer_tokens(get_current_user_id(), $this->id);
                return !empty($tokens);
            } catch (Exception $e) {
                $this->log('Token validation failed: ' . $e->getMessage());
                return false;
            }
        }

        protected function log($message) {
            try {
                if ($this->debug) {
                    $logger = wc_get_logger();
                    $logger->debug($message, ['source' => 'paytoday']);
                }
            } catch (Exception $e) {
                error_log('PayToday logging failed: ' . $e->getMessage());
            }
        }
    }
});